package com.adrian.desafio_java_literalura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesafioJavaLiteraluraApplication {

	public static void main(String[] args) {
		SpringApplication.run(DesafioJavaLiteraluraApplication.class, args);
	}

}
