package com.adrian.desafio_java_literalura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesafioJavaLiteraluraApplicationTests {

	@Test
	void contextLoads() {
	}

}
